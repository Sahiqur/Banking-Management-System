import os
import datetime

bank_list=[
    {
        "name":"Sahiqur Rahman",
        "account_number":"11AA",
        "mobile":"01647428045",
        "taka":float(1000),
    },
    {
        "name":"Taifur Rahman",
        "account_number":"12AA",
        "mobile":"01917027296",
        "taka":float(5000),
    }
]
lend_list=[]

def new_member_add():
    print("Are Your a Member in our Bank? Please Check ")
    check= input("Enter Your Name,Account number or mobile : ")
    for bank in bank_list:
        if bank["name"].lower() in check.lower() or bank["account_number"]==check or bank["mobile"]==check:
            print("You are a member of our Bank, You can continue your activities")
            break
        else:
            print("You have to create your account for start your activity")
            name=input("Enter Your Name : ")
            account_number=input("Enter Your New Account Number : ")
            mobile=input("Enter Your Mobile Number : ")    
            taka=float(input("Enter Your Money : "))
            if bank["name"] == name or bank["account_number"]==account_number or bank["mobile"]==mobile:
                print("This member already of our member")
                break
            else:
                new_money={
                    "name":name,
                    "account_number":account_number,
                    "mobile":mobile,
                    "taka":float(taka),
                }
                bank_list.append(new_money)
                save_all_bank()
                print("Succesfully created Your account")
                break


def total_members():
    print("All Members Information")
    for index,bank in enumerate(bank_list):
        print(
            f'{index+1}. {bank["name"]} {bank["account_number"]}  {bank["taka"]} {bank["mobile"]}'
        )
      


def save_all_bank():
    with open("bank.csv","w") as f:
        for bank in bank_list:
            f.write(
             f'{bank["name"]} {bank["account_number"]}  {bank["taka"]} {bank["mobile"]}\n'   
            )

def add_money():
    key=input("Enter your Name, Number Or Account Number : ")
    for index,bank in enumerate(bank_list):
        if bank["account_number"]==key or key.lower() == bank["name"].lower() or key==bank["mobile"]:
            print(f"This is {bank['name']} Account")
            addmoney=float(input("Enter Money = "))
            result=addmoney+bank["taka"]
            new_bank={
                "name":bank["name"],
                "account_number":bank["account_number"],
                "mobile":bank["mobile"],
                "taka":result,
            }
            bank_list.append(new_bank)
            bank_list.pop(index)
            save_all_bank()
            print(f"Succesfully Added {addmoney} taka and Your total ammount {result} Taka")
            break
        
    else:
        print("Warning! This member is not available")
            
def widraw_money():
    key=input("Enter your Name, Number Or Account Number : ")
    for index,bank in enumerate(bank_list):
        if bank["account_number"]==key or key.lower() == bank["name"].lower() or key==bank["mobile"]:
            print(f"This is {bank['name']} Account")
            submoney=float(input("Enter Money = "))
            result=bank["taka"]-submoney
            new_bank={
                "name":bank["name"],
                "account_number":bank["account_number"],
                "mobile":bank["mobile"],
                "taka":result,
            }
            bank_list.append(new_bank)
            bank_list.pop(index)
            save_all_bank()
            print(f"Succesfully widrawed {submoney} taka and Your total ammount {result} Taka")
            break
        
    else:
        print("Warning! This member is not available")


def remove_Member():
    key=input("Enter Your Search Item (Name/Account Number/Mobile) : ")
    for index,bank in enumerate(bank_list):
        if key.lower() == bank["name"] or key == bank["account_number"] or key == bank["mobile"]:
            print(f'{index+1}.{bank["name"]} {bank["account_number"]}  {bank["taka"]} {bank["mobile"]}')
    
    
    remove_permission=input("Do you want to Delete Member ? (Yes/No) : ")
    if remove_permission.lower() == "Yes".lower():    
        select_index=int(input("Enter Select the number for Delete : "))
        bank_list.pop(select_index-1)
        save_all_bank()
        print("The member has been deleted successfully.")
    else:
        print("Thank You..!! Stay with us for taking our Service")
        

def search_information():
    key=input("Enter Your Search Item : ")
    for index,bank in enumerate(bank_list):
        if key.lower() ==  bank["name"] or  key == bank["mobile"] or  key ==  bank["account_number"]:
            print(f'{index+1}.{bank["name"]} {bank["account_number"]}  {bank["taka"]} {bank["mobile"]}')
            break
    else:
        print("Members not Found")


def update_information():
    key=input("Enter your Name, Number Or Account Number : ")
    for index,bank in enumerate(bank_list):
        if bank["account_number"]==key or key.lower() == bank["name"].lower() or key==bank["mobile"]:
            print(f"This is {bank['name']} Account")
            update_name=input("Enter Your Update Name : ")
            update_mobile= input("Enter Your Update Mobile Number : ")
            new_bank={
                "name":update_name,
                "account_number":bank["account_number"],
                "mobile":update_mobile,
                "taka":bank["taka"],
            }
            bank_list.append(new_bank)
            bank_list.pop(index)
            save_all_bank()
            print("Update Successfully")
            break
        
    else:
        print("Warning! This member is not available")







while True:
    print("\n Banking System")
    print("=================")
    print("1. Add New Member")
    print("2. Add Money")
    print("3. Widrawal Money")
    print("4. Display Information")
    print("5. Delete Member")
    print("6. Search Members")
    print("7. Update Members")
    print("8. Exit")
    
    choice=input("Enter Your Choice (1-8) : ")

    if choice == "1":
        new_member_add()
    elif choice == "2":
        add_money()
    elif choice == "3":
        widraw_money()
    elif choice == "4":
        total_members()
    elif choice == "5":
        remove_Member()
    elif choice == "6":
        search_information()
    elif choice == "7":
        update_information()
    elif choice == "8" or choice.lower() == "exit":
        print("Exit")
        break
    else:
        print("Sorry! Wrong Choice")
        
print("Thank You For Using Our Banking System")
        